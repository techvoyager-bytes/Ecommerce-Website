from .models import SiteConfiguration

def site_configuration(request):
    try:
        config = SiteConfiguration.get_config()
    except:
        # Provide default values if database isn't yet set up
        config = type('Config', (), {
            'site_name': 'Skyrock Store',
            'header_text': 'Welcome to Skyrock Store',
            'theme_color': '#198754'
        })
    return {
        'site_config': config
    } 