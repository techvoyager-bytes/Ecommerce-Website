from django.contrib import admin
from .models import Product, Cart
from django.contrib import admin
from django.contrib import admin
from .models import Product, Category
from django.contrib import admin
from .models import Order
from django.contrib import admin
from .models import Order, OrderItem

class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0

class OrderAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'total_price', 'payment_method', 'status', 'ordered_at')
    list_filter = ('status', 'payment_method', 'ordered_at')
    inlines = [OrderItemInline]



class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name']  # Customize fields shown in the list
    search_fields = ['name']  # Make categories searchable by name and description


# store/admin.py
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'price', 'category', 'order')  # Show 'order' in the list view
    list_editable = ('order',)  # Make 'order' editable directly in the list view
    list_filter = ('category',)  # Optionally, filter products by category
    search_fields = ('name', 'description')  # Allow searching by name or description

admin.site.register(Order, OrderAdmin)

admin.site.register(Category, CategoryAdmin)
admin.site.register(Product, ProductAdmin)



admin.site.register(Cart)
