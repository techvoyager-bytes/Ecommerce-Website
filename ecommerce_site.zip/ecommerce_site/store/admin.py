from django.contrib import admin
from .models import Product, Category, Order, OrderItem
from django.utils.html import format_html

class OrderItemInline(admin.TabularInline):
    model = OrderItem
    extra = 0
    readonly_fields = ['product', 'quantity', 'product_price', 'total_price']
    can_delete = False
    max_num = 0
    
    def has_add_permission(self, request, obj=None):
        return False

@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'get_items_summary', 'phone_number', 'location', 'total_price', 'payment_method', 'status', 'ordered_at']
    list_filter = ['status', 'payment_method', 'ordered_at']
    search_fields = ['user__username', 'phone_number', 'location']
    readonly_fields = ['ordered_at', 'payment_method', 'total_price', 'user']
    list_editable = ['status']
    inlines = [OrderItemInline]
    
    fieldsets = (
        ('Order Information', {
            'fields': (
                'user',
                'ordered_at',
                'status',
                'total_price',
            )
        }),
        ('Delivery Details', {
            'fields': (
                'phone_number',
                'location',
                'payment_method',
            ),
            'classes': ('wide',)
        }),
    )

    def get_items_summary(self, obj):
        items = obj.items.all()
        items_html = "<br>".join([
            f"• {item.product.name} (x{item.quantity}) - KES {item.total_price}"
            for item in items
        ])
        return format_html(items_html)
    get_items_summary.short_description = 'Order Items'

    def get_delivery_info(self, obj):
        return format_html(
            f"📱 {obj.phone_number}<br>📍 {obj.location}"
        )
    get_delivery_info.short_description = 'Delivery Info'

    actions = ['mark_as_shipped', 'mark_as_delivered', 'mark_as_pending']

    def mark_as_shipped(self, request, queryset):
        queryset.update(status='Shipped')
    mark_as_shipped.short_description = "Mark selected orders as Shipped"

    def mark_as_delivered(self, request, queryset):
        queryset.update(status='Delivered')
    mark_as_delivered.short_description = "Mark selected orders as Delivered"

    def mark_as_pending(self, request, queryset):
        queryset.update(status='Pending')
    mark_as_pending.short_description = "Mark selected orders as Pending"

@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ['name', 'price', 'category']
    list_filter = ['category']
    search_fields = ['name']
    ordering = ['order']

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name']
    search_fields = ['name']

@admin.register(OrderItem)
class OrderItemAdmin(admin.ModelAdmin):
    list_display = ['order', 'product', 'quantity', 'product_price', 'total_price']
    list_filter = ['order__status']
    search_fields = ['order__id', 'product__name']
    readonly_fields = ['order', 'product', 'quantity', 'product_price', 'total_price']
