from django.db import models
from django.contrib.auth.models import User
from django.shortcuts import render, redirect
from django.utils import timezone
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django import forms
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django import forms
from django.contrib.auth.forms import AuthenticationForm
from django.utils import timezone
from ckeditor_uploader.fields import RichTextUploadingField
from django.core.cache import cache

class CustomLoginForm(AuthenticationForm):
    class Meta:
        model = User
        fields = ['username', 'password']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            field.widget.attrs.update({
                'class': 'form-control',
                'placeholder': f'Enter your {field.label.lower()}'
            })


class CustomSignUpForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['username', 'email', 'password1', 'password2']

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for field_name, field in self.fields.items():
            field.widget.attrs.update({
                'class': 'form-control',
                'placeholder': f'Enter your {field.label.lower()}'
            })



class SignUpForm(UserCreationForm):
    email = forms.EmailField(required=True)
    first_name = forms.CharField(max_length=100, required=True)
    last_name = forms.CharField(max_length=100, required=True)

    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'password1', 'password2')

class Category(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField(blank=True)

    def __str__(self):
        return self.name


class Product(models.Model):
    name = models.CharField(max_length=255)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField()
    image = models.ImageField(upload_to='product_images/', blank=True, null=True)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    order = models.PositiveIntegerField(default=0)

    def __str__(self):
        return self.name

    class Meta:
        ordering = ['order']


class Cart(models.Model):
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    created_at = models.DateTimeField(default=timezone.now)  # Default to current time

    def get_total_price(self):
        return self.product.price * self.quantity

    def __str__(self):
        return f'{self.quantity} x {self.product.name}'

class CartItem(models.Model):
    cart = models.ForeignKey(Cart, related_name='cart_items', on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    total = models.DecimalField(max_digits=10, decimal_places=2, default=0)

    def save(self, *args, **kwargs):
        self.total = self.product.price * self.quantity
        super().save(*args, **kwargs)

    def __str__(self):
        return f"{self.quantity} of {self.product.name}"


class Order(models.Model):
    PAYMENT_METHODS = [
        ('pay_on_delivery', 'Pay on Delivery'),
        ('mpesa', 'Mpesa'),
    ]
    
    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('Shipped', 'Shipped'),
        ('Delivered', 'Delivered'),
        ('Cancelled', 'Cancelled'),
    ]

    user = models.ForeignKey(User, on_delete=models.CASCADE)
    phone_number = models.CharField(max_length=15)
    location = models.CharField(max_length=255)
    payment_method = models.CharField(max_length=20, choices=PAYMENT_METHODS)
    total_price = models.DecimalField(max_digits=10, decimal_places=2)
    status = models.CharField(
        max_length=20, 
        choices=STATUS_CHOICES,
        default='Pending'
    )
    ordered_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ['-ordered_at']

    def __str__(self):
        return f"Order #{self.id} by {self.user.username}"


class OrderItem(models.Model):
    order = models.ForeignKey(Order, related_name='items', on_delete=models.CASCADE)
    product = models.ForeignKey('Product', on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField()
    product_price = models.DecimalField(max_digits=10, decimal_places=2)
    total_price = models.DecimalField(max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.quantity} x {self.product.name} in Order #{self.order.id}"

    def save(self, *args, **kwargs):
        if not self.total_price:
            self.total_price = self.quantity * self.product_price
        super().save(*args, **kwargs)


def cart_view(request):
    # Get or create a cart for the current user
    cart, created = Cart.objects.get_or_create(user=request.user)

    if request.method == 'POST':
        # Handle adding/removing products from the cart
        product_id = request.POST.get('product_id')
        action = request.POST.get('action')  # 'add' or 'remove'

        product = Product.objects.get(id=product_id)

        # Add item
        if action == 'add':
            cart_item, created = CartItem.objects.get_or_create(cart=cart, product=product)
            cart_item.quantity += 1
            cart_item.save()
        # Remove item
        elif action == 'remove':
            cart_item = CartItem.objects.get(cart=cart, product=product)
            cart_item.delete()

        return redirect('cart')  # Redirect back to the cart page

    cart_items = cart.cart_items.all()
    return render(request, 'store/cart.html', {'cart': cart, 'cart_items': cart_items}) 

class SiteConfiguration(models.Model):
    site_name = models.CharField(max_length=100, default="Skyrock Store")
    header_text = models.CharField(max_length=200, default="Welcome to Skyrock Store")
    subheader_text = models.CharField(max_length=200, default="Discover our amazing products at great prices!")
    theme_color = models.CharField(
        max_length=7,
        default="#198754",
        help_text="Enter hex color code (e.g., #198754)"
    )
    
    def __str__(self):
        return self.site_name
        
    def save(self, *args, **kwargs):
        # Clear the cache when configuration is updated
        cache.delete('site_config')
        super().save(*args, **kwargs)
        
    @classmethod
    def get_config(cls):
        # Get or create the configuration from cache
        config = cache.get('site_config')
        if config is None:
            config, created = cls.objects.get_or_create(pk=1)
            cache.set('site_config', config)
        return config 