from django.conf import settings
import requests
import base64
from datetime import datetime
import json

class MpesaClient:
    def __init__(self):
        self.business_shortcode = settings.MPESA_SHORTCODE
        self.passkey = settings.MPESA_PASSKEY
        self.consumer_key = settings.MPESA_CONSUMER_KEY
        self.consumer_secret = settings.MPESA_CONSUMER_SECRET
        self.access_token = self.generate_access_token()

    def generate_access_token(self):
        """Generate M-Pesa API access token"""
        try:
            url = "https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials"
            response = requests.get(
                url,
                auth=requests.auth.HTTPBasicAuth(self.consumer_key, self.consumer_secret)
            )
            return response.json()['access_token']
        except Exception as e:
            print(f"Error generating access token: {str(e)}")
            return None

    def initiate_stk_push(self, phone_number, amount):
        """Initiate STK push"""
        try:
            timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
            password = base64.b64encode(
                (self.business_shortcode + self.passkey + timestamp).encode()
            ).decode('utf-8')

            # Format phone number
            if phone_number.startswith('+254'):
                phone_number = phone_number[1:]
            elif phone_number.startswith('0'):
                phone_number = '254' + phone_number[1:]
            elif not phone_number.startswith('254'):
                phone_number = '254' + phone_number

            payload = {
                "BusinessShortCode": self.business_shortcode,
                "Password": password,
                "Timestamp": timestamp,
                "TransactionType": "CustomerPayBillOnline",
                "Amount": str(int(amount)),
                "PartyA": phone_number,
                "PartyB": self.business_shortcode,
                "PhoneNumber": phone_number,
                "CallBackURL": settings.MPESA_CALLBACK_URL,
                "AccountReference": "OndiekiStore",
                "TransactionDesc": "Payment for order"
            }

            headers = {
                "Authorization": f"Bearer {self.access_token}",
                "Content-Type": "application/json"
            }

            response = requests.post(
                "https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest",
                json=payload,
                headers=headers
            )

            return response.json()

        except Exception as e:
            print(f"Error initiating STK push: {str(e)}")
            return None

    def verify_payment(self, checkout_request_id):
        """Verify payment status"""
        try:
            # First, ensure we have a valid access token
            if not self.access_token:
                self.access_token = self.generate_access_token()
                if not self.access_token:
                    return {'status_code': 500, 'error': 'Could not generate access token'}

            timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
            password_str = f"{self.business_shortcode}{self.passkey}{timestamp}"
            password = base64.b64encode(password_str.encode()).decode('utf-8')

            payload = {
                "BusinessShortCode": self.business_shortcode,
                "Password": password,
                "Timestamp": timestamp,
                "CheckoutRequestID": checkout_request_id
            }

            headers = {
                "Authorization": f"Bearer {self.access_token}",
                "Content-Type": "application/json"
            }

            print("\n=== Verification Request Details ===")
            print(f"Access Token: {self.access_token}")
            print(f"Endpoint: https://sandbox.safaricom.co.ke/mpesa/stkpushquery/v1/query")
            print(f"Headers: {json.dumps(headers, indent=2)}")
            print(f"Payload: {json.dumps(payload, indent=2)}")

            response = requests.post(
                "https://sandbox.safaricom.co.ke/mpesa/stkpushquery/v1/query",
                json=payload,
                headers=headers
            )

            print("\n=== Response Details ===")
            print(f"Status Code: {response.status_code}")
            print(f"Response Headers: {dict(response.headers)}")
            print(f"Response Body: {response.text}")

            if response.status_code == 200:
                response_data = response.json()
                print(f"\nParsed Response: {json.dumps(response_data, indent=2)}")
                
                # Extract the result code and description
                result = response_data.get('ResultCode', None)
                desc = response_data.get('ResultDesc', '')
                
                return {
                    'status_code': response.status_code,
                    'response': {
                        'ResultCode': result,
                        'ResultDesc': desc,
                        'raw_response': response_data
                    }
                }
            else:
                print(f"\nError Response: {response.status_code}")
                return {
                    'status_code': response.status_code,
                    'error': f"HTTP {response.status_code}: {response.text}"
                }

        except Exception as e:
            print(f"\nError in verify_payment: {str(e)}")
            return {
                'status_code': 500,
                'error': str(e)
            } 