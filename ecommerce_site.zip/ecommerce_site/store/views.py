from django.shortcuts import render, redirect
from django.contrib import messages
import json
from decimal import Decimal
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from .models import Product
from django.shortcuts import render, get_object_or_404
from .models import Product, Category
# views.py
from django.shortcuts import render, redirect
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required
from .forms import SignUpForm
from .models import Order  # Assuming you have an Order model for user orders
from .models import Order, OrderItem
from decimal import Decimal

# User registration view
def sign_up(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)  # Automatically log in after registration
            return redirect('home')  # Redirect to home page after signup
    else:
        form = SignUpForm()
    return render(request, 'store/sign_up.html', {'form': form})

# User login view
def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'store/login.html', {'form': form})

# User panel view
@login_required
def user_panel(request):
    orders = Order.objects.filter(user=request.user)  # Assuming 'Order' model has a user foreign key
    return render(request, 'store/user_panel.html', {'orders': orders})



def home(request):
    categories = Category.objects.all()
    category_id = request.GET.get('category', None)

    if category_id:
        products = Product.objects.filter(category_id=category_id).order_by('order')
    else:
        products = Product.objects.all().order_by('order')

    context = {
        'products': products,
        'categories': categories,
    }
    return render(request, 'store/home.html', context)

def category_products(request, slug):
    category = get_object_or_404(Category, slug=slug)
    products = Product.objects.filter(category=category)
    categories = Category.objects.all()
    return render(request, 'store/home.html', {'products': products, 'categories': categories, 'current_category': category})


# View for adding a product to the cart
def add_to_cart(request, pk):
    product = get_object_or_404(Product, pk=pk)

    if 'cart' not in request.session:
        request.session['cart'] = {}

    cart = request.session['cart']

    if str(pk) in cart:
        cart[str(pk)]['quantity'] += 1
    else:
        cart[str(pk)] = {
            'name': product.name,
            'price': str(product.price),
            'quantity': 1,
        }

    request.session['cart'] = cart
    request.session.modified = True

    # Add a success message
    messages.success(request, f"'{product.name}' has been added to your cart!")

    return redirect('product_detail', pk=pk)



from django.shortcuts import render, redirect
from decimal import Decimal
from django.contrib import messages

def cart(request):
    # Get the cart data from the session
    cart = request.session.get('cart', {})  # Retrieve the cart from the session

    if request.method == "POST":
        # Update quantities from the form submission
        for key, value in request.POST.items():
            if key.startswith("quantities_"):
                product_id = key.split("_")[1]  # Extract the product ID from the input name
                try:
                    quantity = int(value)
                    if quantity > 0:
                        # Update the quantity in the session cart
                        cart[product_id]['quantity'] = quantity
                    else:
                        # Remove the product from the cart if quantity is zero
                        del cart[product_id]
                except (ValueError, KeyError):
                    messages.error(request, f"Invalid quantity for product {product_id}.")
        
        # Save the updated cart back to the session
        request.session['cart'] = cart
        messages.success(request, "Cart updated successfully!")
        return redirect('cart')  # Redirect to avoid resubmission on page refresh

    # Convert cart items to a list of dictionaries for display
    cart_items = [
        {
            'product_id': product_id,
            'name': item['name'],
            'price': Decimal(item['price']),
            'quantity': item['quantity'],
            'total': Decimal(item['price']) * item['quantity']
        }
        for product_id, item in cart.items()
    ]

    # Calculate the cart total
    cart_total = sum(item['total'] for item in cart_items)

    return render(request, 'store/cart.html', {'cart_items': cart_items, 'cart_total': cart_total})



# View for displaying product detail (assuming it exists)
def product_detail(request, pk):
    product = Product.objects.get(pk=pk)
    return render(request, 'store/product_detail.html', {'product': product})

# Checkout view (simple for now)
@login_required
def checkout(request):
    cart = request.session.get('cart', {})  # Retrieve cart from session
    cart_total = sum(Decimal(item['price']) * item['quantity'] for item in cart.values())

    if request.method == 'POST':
        # Retrieve data from the form
        phone_number = request.POST.get('phone_number')
        location = request.POST.get('location')
        payment_method = request.POST.get('payment_method')

        # Create the order in the database
        order = Order.objects.create(
            user=request.user,
            phone_number=phone_number,
            location=location,
            payment_method=payment_method,
            total_price=cart_total
        )

        # Add order items to the order
        for product_id, item in cart.items():
            product = Product.objects.get(id=product_id)  # Fetch the product from the database
            OrderItem.objects.create(
                order=order,
                product=product,
                quantity=item['quantity'],
                product_price=Decimal(item['price']),
                total_price=Decimal(item['price']) * item['quantity']
            )

        # Clear the cart after placing the order
        request.session['cart'] = {}

        messages.success(request, "Your order has been placed successfully!")
        return redirect('order_success')  # Redirect to an order confirmation page

    return render(request, 'store/checkout.html', {'cart_total': cart_total})

def order_success(request):
    return render(request, 'store/order_success.html')


def user_orders(request):
    # Assuming the user is logged in
    orders = Order.objects.filter(user=request.user)
    return render(request, 'store/user_orders.html', {'orders': orders})


