from django.shortcuts import render, redirect
from django.contrib import messages
import json
from decimal import Decimal
from django.http import JsonResponse
from django.shortcuts import get_object_or_404
from .models import Product
from django.shortcuts import render, get_object_or_404
from .models import Product, Category
# views.py
from django.shortcuts import render, redirect
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required
from .forms import SignUpForm
from .models import Order  # Assuming you have an Order model for user orders
from .models import Order, OrderItem
from decimal import Decimal
from datetime import datetime
from django.urls import reverse
import requests
import base64
import json
from django.conf import settings
from django.views.decorators.csrf import csrf_exempt
import logging
from .mpesa import MpesaClient

logger = logging.getLogger(__name__)

# User registration view
def sign_up(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)  # Automatically log in after registration
            return redirect('home')  # Redirect to home page after signup
    else:
        form = SignUpForm()
    return render(request, 'store/sign_up.html', {'form': form})

# User login view
def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'store/login.html', {'form': form})

# User panel view
@login_required
def user_panel(request):
    # Get all orders for the user, including related items
    orders = Order.objects.filter(user=request.user).prefetch_related('items', 'items__product')
    return render(request, 'store/user_panel.html', {'orders': orders})



def home(request):
    categories = Category.objects.all()
    category_id = request.GET.get('category', None)

    if category_id:
        products = Product.objects.filter(category_id=category_id).order_by('order')
    else:
        products = Product.objects.all().order_by('order')

    context = {
        'products': products,
        'categories': categories,
    }
    return render(request, 'store/home.html', context)

def category_products(request, slug):
    category = get_object_or_404(Category, slug=slug)
    products = Product.objects.filter(category=category)
    categories = Category.objects.all()
    return render(request, 'store/home.html', {'products': products, 'categories': categories, 'current_category': category})


# View for adding a product to the cart
def add_to_cart(request, pk):
    product = get_object_or_404(Product, pk=pk)

    if 'cart' not in request.session:
        request.session['cart'] = {}

    cart = request.session['cart']

    if str(pk) in cart:
        cart[str(pk)]['quantity'] += 1
    else:
        cart[str(pk)] = {
            'name': product.name,
            'price': str(product.price),
            'quantity': 1,
        }

    request.session['cart'] = cart
    request.session.modified = True

    # If it's an AJAX request, return JSON response
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse({
            'status': 'success',
            'message': f"'{product.name}' has been added to your cart!"
        })

    # For non-AJAX requests (like from product detail page)
    messages.success(request, f"'{product.name}' has been added to your cart!")
    referer_url = request.META.get('HTTP_REFERER')
    if referer_url:
        return redirect(referer_url)
    return redirect('home')



from django.shortcuts import render, redirect
from decimal import Decimal
from django.contrib import messages

def cart(request):
    # Get the cart data from the session
    cart = request.session.get('cart', {})  # Retrieve the cart from the session

    if request.method == "POST":
        # Update quantities from the form submission
        for key, value in request.POST.items():
            if key.startswith("quantities_"):
                product_id = key.split("_")[1]  # Extract the product ID from the input name
                try:
                    quantity = int(value)
                    if quantity > 0:
                        # Update the quantity in the session cart
                        cart[product_id]['quantity'] = quantity
                    else:
                        # Remove the product from the cart if quantity is zero
                        del cart[product_id]
                except (ValueError, KeyError):
                    messages.error(request, f"Invalid quantity for product {product_id}.")
        
        # Save the updated cart back to the session
        request.session['cart'] = cart
        messages.success(request, "Cart updated successfully!")
        return redirect('cart')  # Redirect to avoid resubmission on page refresh

    # Convert cart items to a list of dictionaries for display
    cart_items = [
        {
            'product_id': product_id,
            'name': item['name'],
            'price': Decimal(item['price']),
            'quantity': item['quantity'],
            'total': Decimal(item['price']) * item['quantity']
        }
        for product_id, item in cart.items()
    ]

    # Calculate the cart total
    cart_total = sum(item['total'] for item in cart_items)

    return render(request, 'store/cart.html', {'cart_items': cart_items, 'cart_total': cart_total})



# View for displaying product detail (assuming it exists)
def product_detail(request, pk):
    product = Product.objects.get(pk=pk)
    return render(request, 'store/product_detail.html', {'product': product})

def order_success(request):
    return render(request, 'store/order_success.html')


def user_orders(request):
    # Assuming the user is logged in
    orders = Order.objects.filter(user=request.user)
    return render(request, 'store/user_orders.html', {'orders': orders})

@csrf_exempt
def mpesa_callback(request):
    print("\n=== M-Pesa Callback Received ===")
    print(f"Time: {datetime.now()}")
    print(f"Method: {request.method}")
    
    if request.method == 'POST':
        try:
            # Log raw data
            raw_data = request.body.decode()
            print(f"\nRaw Data: {raw_data}")
            
            # Parse the response
            response = json.loads(raw_data)
            print(f"\nParsed Data: {json.dumps(response, indent=2)}")
            
            callback_data = response.get('Body', {}).get('stkCallback', {})
            result_code = callback_data.get('ResultCode')
            result_desc = callback_data.get('ResultDesc')
            merchant_request_id = callback_data.get('MerchantRequestID')
            checkout_request_id = callback_data.get('CheckoutRequestID')
            
            print(f"\nResult Code: {result_code}")
            print(f"Description: {result_desc}")
            print(f"Merchant Request ID: {merchant_request_id}")
            print(f"Checkout Request ID: {checkout_request_id}")

            if result_code == 0:  # Successful payment
                metadata = callback_data.get('CallbackMetadata', {}).get('Item', [])
                payment_data = {}
                
                # Extract payment details
                for item in metadata:
                    name = item.get('Name')
                    value = item.get('Value')
                    payment_data[name] = value
                
                print("\nPayment Details:")
                print(f"Amount: {payment_data.get('Amount')}")
                print(f"Receipt Number: {payment_data.get('MpesaReceiptNumber')}")
                print(f"Transaction Date: {payment_data.get('TransactionDate')}")
                print(f"Phone Number: {payment_data.get('PhoneNumber')}")

                # Store successful transaction details in session
                request.session['mpesa_success'] = {
                    'receipt_number': payment_data.get('MpesaReceiptNumber'),
                    'amount': payment_data.get('Amount'),
                    'phone': payment_data.get('PhoneNumber'),
                    'date': payment_data.get('TransactionDate'),
                    'checkout_request_id': checkout_request_id
                }
                
                print("\nPayment Successful! ✓")
                
            else:  # Failed payment
                error_reason = result_desc
                print(f"\nPayment Failed: {error_reason}")
                
                # Store failure details in session
                request.session['mpesa_error'] = {
                    'code': result_code,
                    'description': error_reason,
                    'checkout_request_id': checkout_request_id
                }
            
            print("\n=== Callback Processing Complete ===")
            return JsonResponse({
                'status': 'success',
                'message': 'Callback processed successfully',
                'result_code': result_code,
                'result_desc': result_desc
            })
            
        except json.JSONDecodeError as e:
            print(f"\nError decoding JSON: {str(e)}")
            return JsonResponse({
                'status': 'error',
                'message': 'Invalid JSON data'
            }, status=400)
            
        except Exception as e:
            print(f"\nError processing callback: {str(e)}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            }, status=500)
    
    print("\nInvalid request method")
    return JsonResponse({
        'status': 'error',
        'message': 'Invalid request method'
    }, status=405)


@login_required
def checkout(request):
    cart = request.session.get('cart', {})
    
    if not cart:
        messages.error(request, "Your cart is empty!")
        return redirect('cart')
    
    cart_total = sum(Decimal(item['price']) * item['quantity'] for item in cart.values())

    if request.method == 'POST':
        phone_number = request.POST.get('phone_number')
        location = request.POST.get('location')
        payment_method = request.POST.get('payment_method')

        print(f"\n=== Checkout Form Data ===")
        print(f"Phone Number: {phone_number}")
        print(f"Location: {location}")
        print(f"Payment Method: {payment_method}")

        if payment_method == 'mpesa':
            mpesa = MpesaClient()
            stk_push_response = mpesa.initiate_stk_push(
                phone_number=phone_number,
                amount=float(cart_total)
            )
            
            print("\n=== STK Push Response ===")
            print(json.dumps(stk_push_response, indent=2))
            
            if (stk_push_response and 
                stk_push_response.get('ResponseCode') == '0' and 
                stk_push_response.get('CheckoutRequestID')):
                
                request.session['mpesa_payment'] = {
                    'checkout_request_id': stk_push_response['CheckoutRequestID'],
                    'merchant_request_id': stk_push_response['MerchantRequestID'],
                    'amount': float(cart_total),
                    'phone_number': phone_number,
                    'location': location
                }
                messages.success(request, stk_push_response.get('CustomerMessage'))
                return redirect('verify_payment')
            else:
                print("STK Push Failed:", stk_push_response)
                messages.error(request, "Failed to initiate M-Pesa payment. Please try again.")
                return redirect('checkout')

        # Handle pay on delivery
        try:
            # Create the order
            order = Order.objects.create(
                user=request.user,
                phone_number=phone_number,
                location=location,
                payment_method=payment_method,
                total_price=cart_total
            )

            # Create order items
            for product_id, item in cart.items():
                product = Product.objects.get(id=product_id)
                OrderItem.objects.create(
                    order=order,
                    product=product,
                    quantity=item['quantity'],
                    product_price=Decimal(item['price']),
                    total_price=Decimal(item['price']) * item['quantity']
                )

            # Clear the cart
            request.session['cart'] = {}
            messages.success(request, "Your order has been placed successfully!")
            return redirect('order_success')

        except Exception as e:
            messages.error(request, f"Error processing your order: {str(e)}")
            return redirect('checkout')

    # For GET request, just show the checkout form
    return render(request, 'store/checkout.html', {
        'cart_total': cart_total,
        'cart_items': [
            {
                'id': k,
                'name': v['name'],
                'price': v['price'],
                'quantity': v['quantity'],
                'total': Decimal(v['price']) * v['quantity']
            } for k, v in cart.items()
        ]
    })


def verify_payment(request):
    payment_info = request.session.get('mpesa_payment')
    if not payment_info:
        messages.error(request, "No payment to verify")
        return redirect('checkout')

    if request.method == 'GET' and not request.GET.get('check_status'):
        return render(request, 'store/payment_verification.html', {'payment_info': payment_info})

    checkout_request_id = payment_info['checkout_request_id']
    print(f"\nVerifying payment for CheckoutRequestID: {checkout_request_id}")

    mpesa = MpesaClient()
    result = mpesa.verify_payment(checkout_request_id)
    
    if not result:
        messages.error(request, "Could not verify payment status. Please try again.")
        return render(request, 'store/payment_verification.html', {'payment_info': payment_info})

    print(f"\nVerification Result: {json.dumps(result, indent=2)}")

    if result['status_code'] == 200:
        response_data = result.get('response', {})
        result_code = response_data.get('ResultCode')
        result_desc = response_data.get('ResultDesc')

        if result_code == 0 or (isinstance(result_code, str) and result_code == "0"):  # Success
            try:
                # Get cart data
                cart = request.session.get('cart', {})
                
                # Create order with location
                order = Order.objects.create(
                    user=request.user,
                    phone_number=payment_info['phone_number'],
                    location=payment_info.get('location', 'Unknown'),  # Get location from payment info
                    payment_method='mpesa',
                    total_price=payment_info['amount'],
                    status='Pending'
                )

                # Create order items
                for product_id, item in cart.items():
                    product = Product.objects.get(id=product_id)
                    OrderItem.objects.create(
                        order=order,
                        product=product,
                        quantity=item['quantity'],
                        product_price=Decimal(item['price']),
                        total_price=Decimal(item['price']) * item['quantity']
                    )

                print(f"\nOrder created successfully: Order ID {order.id}")
                print(f"Delivery Location: {order.location}")

                # Clear sessions
                del request.session['mpesa_payment']
                request.session['cart'] = {}
                
                messages.success(request, "Payment completed successfully! Your order has been placed.")
                return redirect('order_success')

            except Exception as e:
                print(f"Error creating order: {str(e)}")
                messages.error(request, "Error processing order. Please contact support.")
                return redirect('checkout')

        elif result_code == 1032:  # Cancelled
            del request.session['mpesa_payment']
            messages.warning(request, "Payment was cancelled.")
            return redirect('checkout')

        elif result_code == 1037:  # Timeout
            del request.session['mpesa_payment']
            messages.warning(request, "Payment session expired.")
            return redirect('checkout')

        else:
            messages.warning(request, f"Payment status: {result_desc}")
    else:
        messages.error(request, f"Error checking payment status: {result.get('error', 'Unknown error')}")

    return render(request, 'store/payment_verification.html', {
        'payment_info': payment_info,
        'verification_result': result
    })

@login_required
def test_callback(request):
    """View to test M-Pesa callbacks"""
    # Simulate successful payment
    success_data = {
        "Body": {
            "stkCallback": {
                "MerchantRequestID": "test-123",
                "CheckoutRequestID": request.session.get('mpesa_payment', {}).get('checkout_request_id'),
                "ResultCode": 0,
                "ResultDesc": "The service request is processed successfully.",
                "CallbackMetadata": {
                    "Item": [
                        {"Name": "Amount", "Value": 1.00},
                        {"Name": "MpesaReceiptNumber", "Value": "TEST123456"},
                        {"Name": "TransactionDate", "Value": 20191219102115},
                        {"Name": "PhoneNumber", "Value": 254712345678}
                    ]
                }
            }
        }
    }
    
    # Make request to callback URL
    response = requests.post(
        settings.MPESA_CALLBACK_URL,
        json=success_data,
        headers={'Content-Type': 'application/json'}
    )
    
    return JsonResponse({
        'callback_url': settings.MPESA_CALLBACK_URL,
        'request_data': success_data,
        'response': response.json(),
        'status_code': response.status_code
    })

@csrf_exempt
def callback_status(request):
    return JsonResponse({
        'status': 'online',
        'timestamp': str(datetime.now()),
        'callback_url': settings.MPESA_CALLBACK_URL
    })

@login_required
def test_mpesa_callback(request):
    """Test endpoint to simulate M-Pesa callbacks"""
    # Successful payment simulation
    success_data = {
        "Body": {
            "stkCallback": {
                "MerchantRequestID": "29115-34620561-1",
                "CheckoutRequestID": "ws_CO_191220191020363925",
                "ResultCode": 0,
                "ResultDesc": "The service request is processed successfully.",
                "CallbackMetadata": {
                    "Item": [
                        {"Name": "Amount", "Value": 1.00},
                        {"Name": "MpesaReceiptNumber", "Value": "TEST123456"},
                        {"Name": "TransactionDate", "Value": 20191219102115},
                        {"Name": "PhoneNumber", "Value": 254712345678}
                    ]
                }
            }
        }
    }

    # Failed payment simulation
    failed_data = {
        "Body": {
            "stkCallback": {
                "MerchantRequestID": "29115-34620561-2",
                "CheckoutRequestID": "ws_CO_191220191020363926",
                "ResultCode": 1032,
                "ResultDesc": "Request cancelled by user"
            }
        }
    }

    # Test both scenarios
    test_cases = [
        ('Success', success_data),
        ('Failure', failed_data)
    ]

    results = []
    for case_name, data in test_cases:
        response = requests.post(
            settings.MPESA_CALLBACK_URL,
            json=data,
            headers={'Content-Type': 'application/json'}
        )
        results.append({
            'case': case_name,
            'status_code': response.status_code,
            'response': response.json()
        })

    return JsonResponse({
        'callback_url': settings.MPESA_CALLBACK_URL,
        'test_results': results
    })


