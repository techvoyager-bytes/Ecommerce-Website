import json
from channels.generic.websocket import WebsocketConsumer

class PaymentVerificationConsumer(WebsocketConsumer):
    def connect(self):
        self.accept()
        
    def receive(self, text_data):
        data = json.loads(text_data)
        checkout_id = data.get('checkout_id')
        
        # Query M-Pesa status
        status = verify_mpesa_payment(checkout_id)
        
        # Send status back to client
        self.send(text_data=json.dumps({
            'status': status
        })) 